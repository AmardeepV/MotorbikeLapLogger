#include <Arduino.h>
#ifdef NICLA_LIVE_BLE
#include "LiveBluetooth.h"
void setup() { LiveBluetooth::begin(); }
void loop() {
    LiveBluetooth::update();
    // Arduino's mbed main loop does not sleep. Let the Cordio controller thread
    // run between iterations, including command rejection/early-return paths.
    delay(1);
}
#else
#include "SensorDiagnostics.h"
void setup() { Serial.begin(115200); SensorDiagnostics::begin(); }
void loop() { SensorDiagnostics::update(); }
#endif
